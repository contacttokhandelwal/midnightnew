<?php
$UTF8_TO_ASCII[0xd3] = array(

);
