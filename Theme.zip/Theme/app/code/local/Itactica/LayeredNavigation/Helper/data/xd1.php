<?php
$UTF8_TO_ASCII[0xd1] = array(

);
