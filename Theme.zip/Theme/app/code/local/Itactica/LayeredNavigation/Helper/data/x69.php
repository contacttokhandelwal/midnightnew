<?php
$UTF8_TO_ASCII[0x69] = array(

);
