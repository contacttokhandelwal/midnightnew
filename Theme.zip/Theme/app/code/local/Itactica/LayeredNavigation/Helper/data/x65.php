<?php
$UTF8_TO_ASCII[0x65] = array(

);
